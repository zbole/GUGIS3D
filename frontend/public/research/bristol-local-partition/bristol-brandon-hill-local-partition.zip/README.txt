Local-partition research in BNG offsets, NOT city ENU. EA 2022 DTM / OGL v3.
Rule each rectangle only when its whole-cell reference bound passes.
Hanging boundary vertices use centre-to-boundary triangles encoded as triangle strips, no triangle-fan primitive.
Shared point IDs and boundary edges: C0, not C1. Reference bound is not unknown-ground accuracy.
Different certified surfaces, not identical-geometry isolation or an optimality theorem. No ArcGIS software run.
