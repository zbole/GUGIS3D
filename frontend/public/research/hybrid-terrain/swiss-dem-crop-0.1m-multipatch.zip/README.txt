ArcGIS-readable research MultiPatch; no ArcGIS software execution.
Open terrain.shp together with SHX/DBF/PRJ/CPG. EPSG:2056; origin [np.float64(2494500.25), np.float64(1141499.75)]; Z copied in metres.
One feature, triangle-strip parts, optional absent M omitted per Esri Table 16.
The continuous certificate is against the frozen bilinear raster reference, not unmeasured ground.
native-recovery.json restores original point IDs, patches and common metadata byte-identically.
Five-component cost excludes this optional recovery sidecar. Both totals are disclosed.
Swiss source: ImplicitTerrain authors / swissALTI3D, Federal Office of Topography swisstopo.
https://www.swisstopo.admin.ch/en/terms-of-use-free-geodata-and-geoservices
https://fengyee.github.io/implicit-terrain/
