Strip organization audit: original hybrid, identical primitives regrouped, and local-triangle baseline.
All original archives included for recovery. Compact model does not retain old patch IDs or first-hit derivative tie order on shared boundaries.
No control/height/refinement changes; oriented primitives SHA and continuous/boundary query audits in results.json.
Full JSON bytes, not memory savings or proved optimality. No ArcGIS software execution.
