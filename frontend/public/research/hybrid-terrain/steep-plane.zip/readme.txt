Finite-scale hybrid research dataset: native JSON, reference grid, query fixture and full scalar/diagnostic results.
Same global tensor candidate family; not optimal arbitrary triangulation or a replication of greedy bisection.
Analytic cases include explicit cell bounds. DEM errors are source-sample checks; random-point reference is interpolated DEM, not measured truth.
No ArcGIS execution. Native models in local projection offsets, not UK city geography.
Swiss source: ImplicitTerrain authors / swissALTI3D, Federal Office of Topography swisstopo.
https://www.swisstopo.admin.ch/en/terms-of-use-free-geodata-and-geoservices
No author weights or code.
