Local conforming triangle benchmark, authored analytic samples only.
Each pair has identical metadata; exact original hybrid geometry and local triangle geometry. Full provenance is in results.json.
Local triangles use unrounded dyadic binary64 XY and exact authored values at midpoints, a stronger oracle than the fixed source lattice.
Worst certified Linfinity selection; convex exact L1 decision, other cases seven-point L1 quadrature plus 1% bound-progress safeguard.
Conforming neighbor closure. No transfer of the paper optimality proof. No ArcGIS software execution.
