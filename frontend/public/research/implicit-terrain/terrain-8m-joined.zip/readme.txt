Joined Triangle Strip XYZ benchmark, 8 m, one EPSG:2056 terrain feature.
Exact compatible endpoint pairs joined; no added/removed/reversed triangles. Optional absent M omitted.
patch-map.json references original parts; join-map.json locates each original part within a joined strip.
Metadata cannot restore shared point IDs or native ruled surfaces. Uncompressed sizes, not ZIP bytes, compared.
Format/readback audit only. ArcGIS software not executed. Not UK city terrain; vertical datum unknown.
DEM: ImplicitTerrain authors / swissALTI3D, Federal Office of Topography swisstopo.
https://fengyee.github.io/implicit-terrain/
https://www.swisstopo.admin.ch/en/terms-of-use-free-geodata-and-geoservices
No author weights or code included.
