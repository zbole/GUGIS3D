Swiss ImplicitTerrain author demo, source SHA a7d90ba9b42712624d82cdfb3b7beae2ef7a2493f88d16846dea82fd8d1bc30d.
Derived research lattice, 8 m. MultiPatch XY EPSG:2056; native x/y are projection offsets from (2494500,1141500). Vertical datum unknown.
Native ruled strips tessellated once; triangle strips unchanged. File-format comparison only; ArcGIS not executed.
DEM attribution: ImplicitTerrain authors / swissALTI3D, Federal Office of Topography swisstopo.
https://fengyee.github.io/implicit-terrain/
https://www.swisstopo.admin.ch/en/terms-of-use-free-geodata-and-geoservices
Not a UK city terrain. No author code or pretrained weights included.
