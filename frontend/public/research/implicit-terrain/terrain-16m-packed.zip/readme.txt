Compact one-feature MultiPatch XYZ, EPSG:2056, 16 m Swiss research sample.
All triangle-strip parts retain exact original XYZ/order. Optional absent measures omitted per Esri Table 16.
patch-map.json maps original patch IDs and kinds; not a lossless native terrain restoration.
GUGIS and Shapefile file sizes are compared separately, not using ZIP bytes. ArcGIS software not executed.
Source DEM: ImplicitTerrain authors / swissALTI3D, Federal Office of Topography swisstopo.
https://fengyee.github.io/implicit-terrain/
https://www.swisstopo.admin.ch/en/terms-of-use-free-geodata-and-geoservices
No author weights or code. Not UK city terrain. Vertical datum unknown.
