Fixed EA 2022 1m DTM source crop, British National Grid EPSG:27700, ODN heights.
Research models use local BNG offsets: NOT city ENU coordinates. Do not directly insert into city scenes.
Open multipatch-*/terrain.shp with SHX/DBF/PRJ/CPG in compatible software. No ArcGIS application was executed.
Native JSON includes shared control IDs and metadata; MultiPatch core does not preserve these.
Native recovery sidecar cost is reported separately and recovers byte-identical JSON.
Continuous certificate is relative to interpolated source raster, not unknown ground truth.
