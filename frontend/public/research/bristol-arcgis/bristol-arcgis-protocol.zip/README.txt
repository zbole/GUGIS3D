Bristol real-terrain ArcGIS Pro protocol
Extract this ZIP to a new folder. Open ArcGIS Pro Python Command Prompt.
python run_bristol_arcgis.py --directory . --output arcgis-result.json
Result must not already exist. Only new temporary FGDBs and this result are written.
Upload result JSON to /compare#bristol-arcgis-run. Import is session-only, never a city save.
Source/native SHA256 and all XYZ vertices checked. FGDB coordinate multiset must be identical.
FGDB patch topology is not verified by coordinate multiset checks.
One warmup, five repeats, medians; no cold-cache guarantee or FPS/memory claim.
ArcGIS read/copy and GUGIS native terrain query are DIFFERENT tasks; do not compute speedup.
Only triangle-strip models included. No flattening of mixed bilinear ruled surfaces.
File-size comparisons are uncompressed five-component SHP/SHX/DBF/PRJ/CPG vs native JSON.
EPSG:27700 local fixtures; ODN heights; not scene ENU. Do not replace your city with native.json.
